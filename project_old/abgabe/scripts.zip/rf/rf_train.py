import os
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import joblib
import numpy as np
import matplotlib.pyplot as plt

# Testing script for 
# Disable CUDA to avoid GPU-related warnings
os.environ["CUDA_VISIBLE_DEVICES"] = ""

# Load data
data = pd.read_csv('powerpredict.csv')

def drop_object_columns(df):
    drop_cols = [c for t, c in zip([t != "object" for t in df.dtypes], df.columns) if not t]
    return df.drop(columns=drop_cols)

DOC = drop_object_columns

# Drop non-numeric columns
data = DOC(data)

# Ensure all data are numeric
X = data.drop('power_consumption', axis=1)
X = DOC(X)
y = data['power_consumption']

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train_sub, _, y_train_sub, _ = train_test_split(X_train, y_train, train_size=0.1, random_state=42)

### _________________________________________________________________________________________________________________________________________________________ ###
### Random Forest Regressor model
# Train and evaluate Random Forest Regressor with default parameters
print("Training Random Forest Regressor with default parameters...")
default_rf = RandomForestRegressor(random_state=42)
default_rf.fit(X_train_sub, y_train_sub)
y_pred_rf_default = default_rf.predict(X_test)
mse_rf_default = mean_squared_error(y_test, y_pred_rf_default)
print(f"Default Random Forest MSE: {mse_rf_default}")

# Hyperparameter tuning for Random Forest Regressor with reduced parameters
print("Starting hyperparameter tuning for Random Forest Regressor...")
rf = RandomForestRegressor(random_state=42)
param_grid = {
    'n_estimators': [50, 100, 150],  # Reduced number of estimators
    'max_depth': [10, 15, 20],  # Reduced max depth
    'min_samples_split': [5, 10],
    'min_samples_leaf': [2, 4]
}
grid_search = GridSearchCV(rf, param_grid, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
grid_search.fit(X_train_sub, y_train_sub)
best_rf_model = grid_search.best_estimator_


# Save the best Random Forest model using a lower precision (model size exceeded 50MBs)
joblib.dump(best_rf_model, 'model_rf.pkl', compress=('xz', 3))

# Evaluate the best Random Forest Regressor model
y_pred_rf_best = best_rf_model.predict(X_test)
mse_rf_best = mean_squared_error(y_test, y_pred_rf_best)
print(f"Best Random Forest MSE: {mse_rf_best}")

# Visualize Grid Search results for Random Forest
results = pd.DataFrame(grid_search.cv_results_)
plt.figure(figsize=(10, 6))
plt.plot(results['param_n_estimators'], -results['mean_test_score'], marker='o')
plt.xlabel('Number of Estimators')
plt.ylabel('Mean Squared Error')
plt.title('Hyperparameter Tuning for Random Forest')
plt.grid(True)
plt.savefig('rf_hyperparameter_tuning.png')
plt.close()


# Evaluate and save the comparison results
comparison_data = {
    'Model': ['Random Forest', 'Random Forest'],
    'Configuration': ['Default', 'Best'],
    'MSE': [mse_rf_default, mse_rf_best]  
}

comparison_df = pd.DataFrame(comparison_data)
comparison_df.to_csv('model_comparison.csv', index=False)

print(comparison_df)
