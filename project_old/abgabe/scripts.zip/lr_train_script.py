import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import joblib

# Disable CUDA to avoid GPU-related warnings
os.environ["CUDA_VISIBLE_DEVICES"] = ""

# Load data
data = pd.read_csv('powerpredict.csv')

def drop_object_columns(df):
    drop_cols = [c for t, c in zip([t != "object" for t in df.dtypes], df.columns) if not t]
    return df.drop(columns=drop_cols)

# Drop non-numeric columns
data = drop_object_columns(data)

# Prepare features and target
X = data.drop('power_consumption', axis=1)
y = data['power_consumption']

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train and evaluate a Linear Regression model
linear_model = LinearRegression()
linear_model.fit(X_train, y_train)

# Predict on test set
y_pred = linear_model.predict(X_test)

# Calculate MSE
mse_linear = mean_squared_error(y_test, y_pred)
print(f"Linear Regression MSE: {mse_linear}")

# Save the linear model
joblib.dump(linear_model, 'linear_model.pkl')

# Save the results to CSV for reporting
comparison_data = {
    'Model': ['Linear Regression'],
    'MSE': [mse_linear]
}

comparison_df = pd.DataFrame(comparison_data)
comparison_df.to_csv('linear_model_comparison.csv', index=False)

print(comparison_df)
