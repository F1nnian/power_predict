import os
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import joblib
import numpy as np
import matplotlib.pyplot as plt

### This script is for fine testing the nn model
# Disable CUDA to avoid GPU-related warnings
os.environ["CUDA_VISIBLE_DEVICES"] = ""
device = torch.device('cpu')


# Load data
data = pd.read_csv('powerpredict.csv')

def drop_object_columns(df):
    drop_cols = [c for t, c in zip([t != "object" for t in df.dtypes], df.columns) if not t]
    return df.drop(columns=drop_cols)

DOC = drop_object_columns

# Drop non-numeric columns
data = DOC(data)

# Ensure all data are numeric
X = data.drop('power_consumption', axis=1).apply(pd.to_numeric, errors='coerce').fillna(0)
y = data['power_consumption']

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

### _________________________________________________________________________________________________________________________________________________________ ###
### Neural Network regression model

# Define Neural Network model using PyTorch
class NeuralNetwork(nn.Module):
    def __init__(self, input_size, hidden_size1=64, hidden_size2=64):
        super(NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.fc3 = nn.Linear(hidden_size2, 1)  # Output a single value for regression
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# Set device to CPU
device = torch.device('cpu')

# Prepare data for PyTorch
X_train_tensor = torch.tensor(X_train.values, dtype=torch.float32).to(device)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).view(-1, 1).to(device)
X_test_tensor = torch.tensor(X_test.values, dtype=torch.float32).to(device)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).view(-1, 1).to(device)

train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

# Function to train the neural network
def train_nn(model, criterion, optimizer, epochs=50):
    model.train()
    for epoch in range(epochs):
        epoch_loss = 0
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)  # MSE Loss
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
    return model

input_size = X_train.shape[1]

# Train and evaluate Neural Network with default parameters
print("Training Neural Network with default parameters...")
default_nn_model = NeuralNetwork(input_size, hidden_size1=64, hidden_size2=64).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(default_nn_model.parameters(), lr=0.001)
trained_default_nn_model = train_nn(default_nn_model, criterion, optimizer, epochs=20)

# Evaluate the default Neural Network model
default_nn_model.eval()
with torch.no_grad():
    val_outputs_default = default_nn_model(X_test_tensor)
    mse_nn_default = criterion(val_outputs_default, y_test_tensor).item()
print(f"Default Neural Network MSE: {mse_nn_default}")

# Hyperparameters for tuning
param_dist = {
    'hidden_size1': [64, 32],
    'hidden_size2': [64, 32],
    'learning_rate': [0.005] # The model was prior tuned with this learning rate and it turned out to be the best fit alpha!
}

results_nn = []

best_nn_model = None
best_loss = float('inf')

# Hyperparameter tuning loop
print("Starting hyperparameter tuning for Neural Network...")
for hidden_size1 in param_dist['hidden_size1']:
    for hidden_size2 in param_dist['hidden_size2']:
        for lr in param_dist['learning_rate']:
            model = NeuralNetwork(input_size, hidden_size1, hidden_size2).to(device)
            criterion = nn.MSELoss()  # MSE Loss for regression
            optimizer = optim.Adam(model.parameters(), lr=lr)
            trained_model = train_nn(model, criterion, optimizer, epochs=20)  # Reduced epochs for quicker tuning
            
            # Evaluate on validation set
            model.eval()
            with torch.no_grad():
                val_outputs = model(X_test_tensor)
                val_loss = criterion(val_outputs, y_test_tensor).item()  # Validation loss
                
                results_nn.append((hidden_size1, hidden_size2, lr, val_loss))
                
                if val_loss < best_loss:
                    best_loss = val_loss
                    best_nn_model = model

# Save the best neural network model
torch.save(best_nn_model.state_dict(), 'model_nn.pth')

# Evaluate the best Neural Network model
best_nn_model.eval()
with torch.no_grad():
    val_outputs_best = best_nn_model(X_test_tensor)
    mse_nn_best = criterion(val_outputs_best, y_test_tensor).item()
print(f"Best Neural Network MSE: {mse_nn_best}")

# Create a comparison table
comparison_data = {
    'Model': ['Random Forest', 'Random Forest', 'Neural Network', 'Neural Network'],
    'Configuration': ['Default', 'Best', 'Default', 'Best'],
    'MSE': [None, None, mse_nn_default, mse_nn_best] 
}

comparison_df = pd.DataFrame(comparison_data)
comparison_df.to_csv('model_comparison.csv', index=False)

print(comparison_df)
